import React from "react";



export default function AdminFooter()
{
    return(
        <footer className="main-footer">
            <strong>Copyright &copy; 2021 <a href="http://clientapp.narola.online:1129/admin/admindashboard">AskMyDoc.com</a>.</strong>
            All rights reserved.
            <div className="float-right d-none d-sm-inline-block">
            {/* <b>Version</b> 3.1.0-rc */}
            </div>
        </footer>
    )
}